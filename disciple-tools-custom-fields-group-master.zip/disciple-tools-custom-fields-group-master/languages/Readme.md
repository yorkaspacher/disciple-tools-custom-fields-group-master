.po and .mo files must be in this format:  
{translation-domain}-{localisation}.po
 
ex:  
dt_starter_plugin.fr_FR.po